<h1 class="contract">exec</h1>

---
spec_version: "0.2.0"
title: Privileged Execute
summary: '{{nowrap executer}} executes a transaction while bypassing authority checks'
icon: /
---

{{executer}} executes the following transaction while bypassing authority checks:
{{to_json trx}}

{{$action.account}} must also authorize this action.
